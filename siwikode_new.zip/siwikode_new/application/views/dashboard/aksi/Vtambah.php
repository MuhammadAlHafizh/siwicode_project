

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-success">Tambah Data</h6>
                        </div>
                        <div class="card-body">
                            <form action="<?= base_url("index.php/Cadmin/aksiTambah/".$role)?>" method="POST">
                                <div class="row">
                                    <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Username</label>
                                                <input type="text" name="username" placeholder="Username" class="form-control">
                                            </div>    
                                    </div>
                                    <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input class="form-control" type="email" name="email" placeholder="Email">
                                            </div>  
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Password</label>
                                                <input type="password" name="password" placeholder="Password" class="form-control" >
                                            </div>    
                                    </div>

                                </div>
                                <div class="footer-right">
                                    <button class="btn btn-success my-1">Simpan</button>
                                </div>
                            </form>    
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->
