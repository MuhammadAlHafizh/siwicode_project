
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tambah Data Wisata</h6>
        </div>
        <div class="card-body">
            <form action="<?= base_url("index.php/Cwisata/aksiTambahWisata/")?>" method="POST">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Nama</label>
                            <input  type="text" name="nama" placeholder="Nama" class="form-control">
                        </div>    
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Email</label>
                            <input class="form-control" type="email" name="email" placeholder="Email">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Jenis Kuliner</label>
                            <select name="jkuliner" id="jkuliner" class="form-control">
                                <?php foreach($jenis_kuliner->result() as $jk){ ?>
                                    <option value="<?=$jk->id_jk?>"><?=$jk->nama_jk?></option>
                                <?php }; ?>
                            </select>
                        </div>
                    </div>
                     <div class="col-sm-6">
                        <div class="form-group">
                            <label>Jenis Wisata</label>
                            <select name="jwisata" id="jwisata" class="form-control">
                                <?php foreach($jenis_wisata->result() as $jw){ ?>
                                    <option value="<?=$jw->id_jw?>"><?=$jw->nama_jw?></option>
                                <?php }; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Web</label>
                            <input class="form-control" type="text" name="web" placeholder="Web">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Rating</label>
                            <select name="rating" id="rating" class="form-control">
                                <option value="1">1 Bintang</option>
                                <option value="2">2 Bintang</option>
                                <option value="3">3 Bintang</option>
                                <option value="4">4 Bintang</option>
                                <option value="5">5 Bintang</option>
                                <option value="6">6 Bintang</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Deskripsi</label>
                            <textarea class="form-control" name="deskripsi"></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Alamat</label>
                            <textarea class="form-control" name="alamat"></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Maps</label>
                            <textarea class="form-control" name="maps"></textarea>
                        </div>
                    </div>
                </div>
                <div class="footer-right">
                     <button class="btn btn-success my-1">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>                