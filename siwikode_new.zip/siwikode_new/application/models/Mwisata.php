<?php

class Mwisata extends CI_Model
{
    public function getWisataAdmin()
    {
        //buat query
        $this->db->select('*');
        $this->db->from('wisata'); 
        $this->db->join('jenis_wisata', 'jenis_wisata.id_jw = wisata.jenis_wisata_id');
        $this->db->join('jenis_kuliner', 'jenis_kuliner.id_jk = wisata.jenis_kuliner_id');
        $wisata = $this->db->get(); 
        return $wisata;
    }

    public function hapusDataWisata($id){
        $this->db->where('id', $id);
        $this->db->delete('wisata');
    }

    public function findWisata($id) {
        $query = $this->db->get_where('wisata', ['id' => $id]);
        return $query->row();
    }

    public function updateWisata($id, $nama, $deskripsi, $email, $alamat, $web, $idJK, $idJW){
        $this->db->where('id', $id);
        $this->db->update('wisata', ["nama_wisata" => $nama, "deskripsi" => $deskripsi, "alamat" => $alamat, "email" => $email, "web" => $web,'jenis_kuliner_id'=> $idJK,'jenis_wisata_id' => $idJW,'id' => $id]);
     }

    public function getJenisWisata(){
        //buat query
        $query = $this->db->get('jenis_wisata');
        return $query;
    }

    public function getJenisKuliner(){
       //buat query
       $query = $this->db->get('jenis_kuliner');
       return $query;
    }

    public function tambahWisata($nama, $deskripsi, $email, $alamat, $web, $idJK, $idJW, $rating, $maps){
        $data = array(
            'nama_wisata' => $nama,
            'email' => $email,
            'deskripsi' => $deskripsi,
            'web' => $web,
            'alamat' => $alamat,
            'jenis_kuliner_id' => $idJK,
            'jenis_wisata_id' => $idJW,
            'bintang' => $rating,
            'maps' => $maps
        );

        $query = $this->db->insert('wisata', $data);
    }


}